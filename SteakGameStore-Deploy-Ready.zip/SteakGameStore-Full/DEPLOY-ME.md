# SteakGameStore — Deploy

## Render
1. Upload this project to GitHub.
2. Render → New → Web Service → select the GitHub repo.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env.example`.
6. Set `BASE_URL` and `QPAY_CALLBACK_URL` to your Render/custom-domain HTTPS URL.

## Required production variables
- `BASE_URL`
- `QPAY_MODE=production`
- `QPAY_CLIENT_ID`
- `QPAY_CLIENT_SECRET`
- `QPAY_INVOICE_CODE`
- `QPAY_INVOICE_RECEIVER_CODE`
- `QPAY_CALLBACK_URL`
- `ADMIN_KEY`

Do not commit `.env` or QPay secrets to GitHub.

## Important
`data.json` is simple file storage for demo/small testing. Before taking real orders at scale, migrate products, orders and codes to PostgreSQL and use transaction-safe code allocation.
